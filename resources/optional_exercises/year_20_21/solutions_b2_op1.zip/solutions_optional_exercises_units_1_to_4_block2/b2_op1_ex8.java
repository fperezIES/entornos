/*
 * Exercise 8
 * 
 * Program that asks the user his/her name and surname and converts it into polite format:
 * Mr/Mrs Surname, Name
 * NOTE: We assume that there will be just one surname
 */ 
 
import java.util.Scanner;

public class b2_op1_ex8
{
	public static String convertName(String name)
	{
		String[] parts = name.split(" ");
		return "Mr/Mrs " + parts[1] + ", " + parts[0];
	}
	
    public static void main(String[] args)
    {
		System.out.println(convertName("María Ferrer"));
    }
}
