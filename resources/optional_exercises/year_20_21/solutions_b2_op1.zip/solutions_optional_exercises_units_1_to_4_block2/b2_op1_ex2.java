/*
 * Exercise 2
 * 
 * Ask numbers to the user until he/she types 0. Then, print the
 * total amount of numbers entered (excluding the final 0)
 */ 

import java.util.Scanner;

public class b2_op1_ex2
{
    public static void main(String[] args) 
    {
        Scanner sc=new Scanner(System.in);
        int number, count = 0;
        
        do
        {
			System.out.printf("Input a number: ");
			number = sc.nextInt();
			
			if (number != 0)
				count++;			
		} while (number != 0);
		
		System.out.println("The total amount of numbers input is: " + count);        
    }
}
