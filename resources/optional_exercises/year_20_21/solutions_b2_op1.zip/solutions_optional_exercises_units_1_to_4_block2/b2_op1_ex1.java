/*
 * Exercise 1
 * 
 * Print first n squared numbers until n entered by the user
 */ 

import java.util.Scanner;

public class b2_op1_ex1 
{
    public static void main(String[] args) 
    {
        Scanner sc=new Scanner(System.in);
        int n;
        
        System.out.printf("Input a number: ");
        n=sc.nextInt();
        
        System.out.printf("The first %d squared numbers are: ",n);
        for(int i =1;i<=n;i++)
        {
            System.out.printf("%d",i*i);
            if (i < n)
				System.out.print(", ");
        }
    }
}
