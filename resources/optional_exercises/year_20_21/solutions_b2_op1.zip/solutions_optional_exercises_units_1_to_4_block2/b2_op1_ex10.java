/*
 * Exercise 10
 * 
 * Program that determines if a number is circular prime or not.
 * A circular prime is a number for which every possible rotation of its digits
 * is a prime number. For instance, 1931 is circular primer, because
 * 1931, 9311, 3119 and 1193 are prime.
 */ 
 
import java.util.Scanner;

public class b2_op1_ex10
{
	public static int rotateNumber(int number)
	{
		// Place first digit at the end
		String aux = "" + number;
		return Integer.parseInt(aux.substring(1) + aux.charAt(0));
	}
	
	// We can get this function from Exercise 3
    public static boolean isPrime(int num)
    {
        int index = 2;
        boolean prime = true;
        
        while(index <= (num/2) && prime)
        {
            if(num % index == 0)
            {
                prime=false;
            }
            index++;
        }
        return prime;
    }
    
    public static void main(String[] args)
    {
        Scanner sc=new Scanner(System.in);
        int num, numLength, count = 0;
        boolean result = true;
        
        System.out.printf("Number? ");
        num = sc.nextInt();
        numLength = ("" + num).length();
        
        while (result && count < numLength)
        {
			result = isPrime(num);
			num = rotateNumber(num);
			count++;
		}
		
		if (result)
			System.out.println("Is circular prime");
		else
			System.out.println("Is NOT circular prime");        
    }
}
