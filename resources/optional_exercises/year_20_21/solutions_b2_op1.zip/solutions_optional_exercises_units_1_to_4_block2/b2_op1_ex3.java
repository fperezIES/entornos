/*
 * Exercise 3
 * 
 * Print the first n prime numbers until the number entered by the user
 */ 

import java.util.Scanner;

public class b2_op1_ex3
{
    public static boolean isPrime(int num)
    {
        int index = 2;
        boolean prime = true;
        
        while(index <= (num/2) && prime)
        {
            if(num % index == 0)
            {
                prime=false;
            }
            index++;
        }
        return prime;
    }
    
    public static void main(String[] args) 
    {
        Scanner sc=new Scanner(System.in);
        int n;
    
        System.out.printf("Input a number: ");
        n = sc.nextInt();
    
        System.out.printf("Prime numbers until %d are:", n);
        for(int i = 2; i <= n; i++)
        {
            if(isPrime(i))
            {
                 System.out.printf(" %d", i);
            }
        }
    }
}
