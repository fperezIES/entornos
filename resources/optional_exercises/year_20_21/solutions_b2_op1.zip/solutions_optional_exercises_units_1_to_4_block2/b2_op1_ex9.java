/*
 * Exercise 9
 * 
 * Program that calculates the sum of digits of a number, both iteratively and recursively
 */ 
 
import java.util.Scanner;

public class b2_op1_ex9 
{
	// Iterative function
	public static int addDigits(int num)
	{
		int sum = 0;
		
		while (num != 0)
		{
			sum += num % 10;
			num /= 10;
		}
		
		return sum;
	}

	// Recursive function
    public static int addDigitsRecursive(int num)
    {
        if(num < 10) 
			return num;
		else
			return num % 10 + addDigitsRecursive(num/10);
    }

    public static void main(String[] args)
    {
        Scanner sc=new Scanner(System.in);
        int num;
        
        System.out.printf("Number? ");
        num=sc.nextInt();
        
        System.out.println(addDigits(num));
        System.out.println(addDigitsRecursive(num));
    }
}
