/*
 * Exercise 5
 * 
 * Program that asks marks to the user. 
 * It shows the average and the marks greater than the average.
 */ 
 
import java.util.Scanner;

public class b2_op1_ex5 
{
    public static void main(String[] args)
    {
        Scanner sc=new Scanner(System.in);
        int num;
        double[] marks;
        double total=0, average=0;

        System.out.printf("How many marks are you going to introduce? ");
        num = sc.nextInt();
        sc.nextLine();

        marks = new double[num];

        for(int i = 0; i < num; i++)
        {
            marks[i] = sc.nextDouble();
            total += marks[i];
        }
        
        average = total / num;
        
        System.out.printf("The average is %.2f and the marks greater than the average are: ",average);

        for(int i = 0; i < num; i++)
        {
            if(marks[i] > average)
                System.out.printf("%.2f ",marks[i]);
        }
    }
}
