/*
 * Exercise 7
 * 
 * Program that asks a month name to the user and tells him/her how many days this month has
 */ 
 
import java.util.Scanner;

public class b2_op1_ex7 {


    public static void main(String[] args)
    {
        Scanner sc=new Scanner(System.in);
        String month;
        int index=0;
        String[] months = {"January","February","March","April","May","June",
			"July","August","September","October","November","December"};
        int[] days = {31,28,31,30,31,30,31,31,30,31,30,31};

        System.out.printf("Month name? ");
        month=sc.nextLine();

        while(!(months[index].equals(month)))
            index++;
            
		System.out.printf("%s has %d days", month, days[index]);
    }
}
