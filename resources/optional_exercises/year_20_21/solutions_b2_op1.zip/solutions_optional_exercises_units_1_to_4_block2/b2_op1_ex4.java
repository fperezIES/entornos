/*
 * Exercise 4
 * 
 * Ask real numbers to the user until he/she types "end". In each iteration, show
 * the maximum, minimum, total sum and average.
 */ 

import java.util.Scanner;

public class b2_op1_ex4
{
    public static void main(String args[]) {
        
        Scanner sc = new Scanner(System.in);
        double number, min = 0, max = 0, add = 0, avg;
        String inputText;
        boolean firstNumber = true;
        int counter = 0;
        
        do 
        {
            System.out.println("Number? ");
            inputText = sc.nextLine();
            
            if (!inputText.equals("end")) 
            {
                number = Double.parseDouble(inputText);
                counter++;
                
                if (firstNumber) 
                {
                    min = max = add = avg = number;
                    firstNumber = false;
                } 
                else 
                {
                    min = min < number ? min: number;
                    max = max > number ? max: number;
                    add += number;
                    avg = add / counter;
                }
                                 
                System.out.printf("min = %.1f  max = %.1f add = %.1f avg = %.1f\n", 
                    min, max, add, avg);
            }
        } while (!inputText.equals("end"));        
    } 
}
