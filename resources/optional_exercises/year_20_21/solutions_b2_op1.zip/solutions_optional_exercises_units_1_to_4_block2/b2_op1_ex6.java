/*
 * Exercise 6
 * 
 * Program that asks marks and student namess to the user. 
 * It shows the average, the names with marks greater than the average and the greatest mark
 */ 
 
import java.util.Scanner;

public class b2_op1_ex6
{
    public static void main(String[] args)
    {
        Scanner sc=new Scanner(System.in);
        int num;
        String nameGreatestMark = "";
        double total=0, average=0, maxMark;
        double[] marks;
        String[] names;

        System.out.printf("How many marks are you going to introduce? ");
        num = sc.nextInt();
        sc.nextLine();

        marks = new double[num];
        names = new String[num];
        
        String[] parts = sc.nextLine().split(" ");
        
        maxMark = 0;
        

        for(int i = 0; i < parts.length; i+=2)
        {
			names[i/2] = parts[i];
			marks[i/2] = Double.parseDouble(parts[i+1]);
			if (marks[i/2] > maxMark)
			{
				maxMark = marks[i/2];
				nameGreatestMark = names[i/2];
			}
				
            total += marks[i/2];
        }
        
        average = total / num;
        
        System.out.printf("The average is %.2f\n", average);
        System.out.println("The students with marks greater than the average are: ");

        for(int i = 0; i < num; i++)
        {
            if(marks[i] > average)
                System.out.println("- " + names[i]);
        }
        
        System.out.println("The student with the greatest mark is " + nameGreatestMark);
    }
}
