package main;

public class GranAlbum extends PhotoAlbum{
    public GranAlbum()
    {
        super(64);
    }

    @Override
    public String toString() {
        return super.toString()+" and I am big";
    }
}
