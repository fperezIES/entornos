package main;

public class PhotoAlbum {
    int pageNumber;

    public PhotoAlbum(int pageNumber)
    {
        this.pageNumber=pageNumber;
    }

    public PhotoAlbum()
    {
        this(16);
    }

    public int getPageNumber()
    {
        return pageNumber;
    }

    public void setPageNumber(int pageNumber)
    {
        this.pageNumber=pageNumber;
    }

    @Override
    public String toString() {
        return "I am an album with "+pageNumber+" pages";
    }
}
