package main;



public class Main {

    public static void main(String[] args) {
	    PhotoAlbum[] myAlbums=new PhotoAlbum[4];

	    myAlbums[0]=new PhotoAlbum();
	    myAlbums[1]=new PhotoAlbum(32);
	    myAlbums[2]=new GranAlbum();
	    myAlbums[3]=new GranAlbum();

	    for(int i=0;i<4;i++)
	    	System.out.println(myAlbums[i]);
    }
}
