package main;

public class Main {

    public static void main(String[] args) {
	ComplexNumber a,b;
	a=new ComplexNumber(3,4);
	b=new ComplexNumber(5,7);
	System.out.println("Sum of "+a+" and "+b+" is: "+ComplexNumber.Sum(a,b));
	System.out.println( "The magnitude of:"+ a + " is: "+a.getMagnitude());
    }
}
