package main;

public class ComplexNumber {
    double realPart;
    double imPart;

    public ComplexNumber(double a,double b)
    {
        realPart=a;
        imPart=b;
    }

    public ComplexNumber()
    {
        this(0,0);
    }

    public double getRealPart() {
        return realPart;
    }

    public void setRealPart(double realPart) {
        this.realPart = realPart;
    }

    public double getImPart() {
        return imPart;
    }

    public void setImPart(double imPart) {
        this.imPart = imPart;
    }

    @Override
    public String toString()
    {
        return realPart +" "+ (imPart>=0?"+"+imPart+"i":"-"+imPart+"i");
    }

    public double getMagnitude()
    {
        return Math.sqrt(Math.pow(realPart,2)+Math.pow(imPart,2));
    }

    public static ComplexNumber Sum(ComplexNumber firstNumber,ComplexNumber secondNumber)
    {
        ComplexNumber result=new ComplexNumber();
        result.realPart=firstNumber.realPart+ secondNumber.realPart;
        result.imPart=firstNumber.imPart+secondNumber.imPart;
        return result;

    }
}
