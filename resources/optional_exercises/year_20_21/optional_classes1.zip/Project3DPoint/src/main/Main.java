package main;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {

        ThreeDPoint[] points=new ThreeDPoint[5];
        Scanner sc=new Scanner(System.in);
        int x=0,y=0,z=0;

	    for(int i=0;i<5;i++)
        {
            System.out.printf("Enter values for x,y,z of a new 3D point: ");
            x=sc.nextInt();
            y=sc.nextInt();
            z=sc.nextInt();
            points[i]=new ThreeDPoint(x,y,z);
        }

	    for(int i=1;i<5;i++)
        {
            System.out.printf("The distance between"+ points[0] + " and " + points[i] +
                                " is %.2f\n",points[0].distanceTo(points[i]));
        }
	    sc.close();
    }
}
