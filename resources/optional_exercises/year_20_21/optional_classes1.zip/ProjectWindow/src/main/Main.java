package main;

import java.util.Random;

public class Main {

    public static void main(String[] args) {
	    Window[] windows=new Window[10];
        Random r=new Random(); //another way of generating random numbers

	    for(int i=0;i<10;i++)
        {
            windows[i]=new Window("Window"+i,r.nextInt(30)+90,r.nextInt(60)+40);
        }

	    for(int i=0;i<10;i++)
        {
            System.out.println(windows[i]);
        }
    }
}
