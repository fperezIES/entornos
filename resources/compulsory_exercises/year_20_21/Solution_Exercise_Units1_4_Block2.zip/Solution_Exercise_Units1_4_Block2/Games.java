/*
 * Exercise for Units 1 to 4, Block 2
 * 
 * Implement some functions and a main program
 * that lets us play 2 different games
 * 
 * IMPORTANT NOTE: none of the comments below is necessary,
 * we leave them for you as an explanation of every function
 */


import java.util.Scanner;

public class Games
{
	/* Generates a random number between min and max (inclusive)
	 * To do this, we need to generate a random number in the
	 * range (max - min), including both edges (so we need to add 1)
	 * and finally we add "min" to this range to move the result
	 * to the target range of [min, max] */
    public static int generateNumber(int min, int max)
    {
        int randomNumber = min + (int)(Math.random() * ((max-min)+1));        
        return randomNumber;
    }
    
    /* Generates and returns an array of 6 random, non repeated
     * numbers between 1 and 49. The array must be sorted. */
    public static int[] generateLottery()
    {
        int[] numbersLottery = new int[6];
        int countNumbersLottery = 0;
        boolean repeatedNumber;
        
        while(countNumbersLottery < numbersLottery.length)
        {
            numbersLottery[countNumbersLottery] = generateNumber(1,49);
            
            // We check if it's repeated. We assume that it's not, and then
            // we look for a number from 0 to countNumbersLottery position
            // that is equal to the new number
            
            repeatedNumber = false;
            
            for(int count = 0; count < countNumbersLottery; count++)
            {
                if(numbersLottery[countNumbersLottery] == numbersLottery[count])
                    repeatedNumber = true;
            }
            
            if(!repeatedNumber)
                countNumbersLottery++;            
        }
        
        // Sort the array (bubble algorithm)
        
        for(int i = 0; i < numbersLottery.length - 1; i++)
        {
            for(int j = i + 1; j < numbersLottery.length; j++)
            {
                if(numbersLottery[i] > numbersLottery[j])
                {
                    int auxNumber = numbersLottery[i];
                    numbersLottery[i] = numbersLottery[j];
                    numbersLottery[j] = auxNumber;
                }
            }
        }
        
        return numbersLottery;
    }
    
    /* Checks the number of hits in a lottery ticket.
     * "user" is user's ticket and "winner" is winner ticker */
    public static int checkLottery(int[] user, int[] winner)
    {
        int hits = 0;
        
        for(int i = 0; i < user.length; i++)
        {
            for(int j = 0; j < winner.length; j++)
            {
                if(user[i] == winner[j])
                    hits++;
            }
        }
        
        return hits;
    }
    
    /* Plays lottery game using the functions above */
    public static void playLottery()
    {
        Scanner sc = new Scanner(System.in);
        int[] userNumbers = new int[6];
        int[] winnerNumbers;
        
        // Read user numbers
        System.out.print("Enter your combination: ");
        for (int i = 0; i < userNumbers.length; i++)
			userNumbers[i] = sc.nextInt();
        
        // Generate winner ticket
        winnerNumbers = generateLottery();
        
        System.out.print("This is the winner combination: ");
        for(int i = 0; i < winnerNumbers.length; i++)
        {
            System.out.print(winnerNumbers[i] + " ");
        }
        
        System.out.println();
        
        // Check hits
        System.out.println("You have " + checkLottery(userNumbers, 
            winnerNumbers) + " hits");
        
    }
    
    /* Function to play Nim game. The user always starts 
     * substracting chips. The one who substracts the last
     * chip on the table loses the game */
    public static void playNim(int chips)
    {
        System.out.println("Playing Nim with " + chips + " chips.");
        
        while(chips > 1)
        {
			chips = userTurn(chips);
			if (chips > 1)
			{
				chips = computerTurn(chips);
			}
		}		
	}
	
	public static int userTurn(int chips)
	{
		Scanner sc = new Scanner(System.in);
		int userChips;
		
		// Read the number of chips until it's valid
		// We can use Math.min to make sure that the user doesn't
		// substract more than the available chips
		do
		{
			System.out.print("Your turn. Choose how many chips to substract: ");
			userChips = sc.nextInt();
		} while (userChips < 1 || userChips > Math.min(3, chips));
            
		chips -= userChips;
		System.out.println(chips + " chips pending");
		
		if (chips == 1)
			System.out.println("You win");
		else if (chips == 0)
			System.out.println("You lose");
			
 		return chips;
	}
	
	public static int computerTurn(int chips)
	{
		int computerChips = generateNumber(1, Math.min(3, chips));
		System.out.println("Computer substracts " + computerChips
			+ " chips.");    

		chips -= computerChips;
		System.out.println(chips + " chips pending");

		if (chips == 1)
			System.out.println("You lose");
		else if (chips == 0)
			System.out.println("You win");
		
		return chips;
	}
    
    /* Main function */
    public static void main(String[] args)
    {
        int numberOfChips;
        
        try
        {
			if(args.length == 0 || 
              ((!args[0].equals("lottery")) && (!args[0].equals("nim"))) ||
              (args[0].equals("nim") && (Integer.parseInt(args[1]) <= 0 || 
               Integer.parseInt(args[1]) > 30)))
			{               
				System.out.println("Wrong input");
			}
            else
            {
                switch(args[0])
                {
                    case "lottery":
                        playLottery();
                        break;
                        
                    case "nim":
                        numberOfChips = Integer.parseInt(args[1]);
                        playNim(numberOfChips);
                        break;
                }
            }
        }
        catch(NumberFormatException a)
        {
            System.out.println("Incorrect number of chips");
        }
    }
}
