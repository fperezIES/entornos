package automation.fx;

import automation.data.*;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextField;

import java.io.*;
import java.net.URL;
import java.util.ResourceBundle;

public class Controller implements Initializable
{
    private static final String STATUS_FILE = "status.dat";

    @FXML
    private Button btnGarage;
    @FXML
    private ComboBox<String> comboGarage;
    @FXML
    private Button btnWindow;
    @FXML
    private ComboBox<String> comboWindow;
    @FXML
    private Button btnHeating;
    @FXML
    private TextField txtHeating;
    @FXML
    private Button btnOven;
    @FXML
    private TextField txtOven;
    @FXML
    private Button btnBathroomLight;
    @FXML
    private Button btnLivingLight;

    private AutomationElement[] elements;

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle)
    {
        comboGarage.getItems().addAll("0", "25", "50", "75", "100");
        comboWindow.getItems().addAll("0", "25", "50", "75", "100");

        elements = new AutomationElement[6];
        elements[0] = new GarageDoor("Garage Door", false, 100);
        elements[1] = new Window("Living Room Window", new Blind("Living room blind", 50));
        elements[2] = new Heating("Bathroom Heating", 25, false);
        elements[3] = new Oven("Kitchen Oven", 200,false);
        elements[4] = new Light("Bathroom Light", false);
        elements[5] = new Light("Living Room Light", false);
        loadStatus();
    }

    public void loadStatus()
    {
        if (new File(STATUS_FILE).exists()) {
            BufferedReader br = null;
            try {
                br = new BufferedReader(new FileReader(STATUS_FILE));
                String line = null;
                int count = 0;
                while (count < elements.length) {
                    line = br.readLine();
                    String[] parts = line.split(";");
                    switch (count) {
                        case 0:
                            GarageDoor gd = (GarageDoor) elements[0];
                            if (parts[1].equals("locked"))
                                gd.lock();
                            else
                                gd.unlock();
                            gd.lower();
                            gd.raise(Integer.parseInt(parts[2]));
                            break;
                        case 1:
                            Window w = (Window) elements[1];
                            if (parts[1].equals("locked"))
                                w.lock();
                            else
                                w.unlock();
                            w.getBlind().lower();
                            w.getBlind().raise(Integer.parseInt(parts[2]));
                            break;
                        case 2:
                            Heating h = (Heating) elements[2];
                            if (parts[1].equals("on"))
                                h.switchOn();
                            else
                                h.switchOff();
                            h.setTemperature(Integer.parseInt(parts[2]));
                            break;
                        case 3:
                            Oven o = (Oven) elements[3];
                            if (parts[1].equals("on"))
                                o.switchOn();
                            else
                                o.switchOff();
                            o.setTemperature(Integer.parseInt(parts[2]));
                            break;
                        case 4:
                            Light l = (Light) elements[4];
                            if (parts[1].equals("on"))
                                l.switchOn();
                            else
                                l.switchOff();
                            break;
                        case 5:
                            l = (Light) elements[5];
                            if (parts[1].equals("on"))
                                l.switchOn();
                            else
                                l.switchOff();
                            break;
                    }
                    count++;
                }
            } catch (Exception e) {
                System.err.println("Error loading initial status");
            } finally {
                try {
                    br.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }

        updateUI();
    }

    public void saveStatus()
    {
        updateElements();
        PrintWriter pw = null;
        try
        {
            pw = new PrintWriter(STATUS_FILE);
            for(AutomationElement e: elements)
                pw.println(e);
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (pw != null)
                pw.close();
        }
    }

    public void switchGarage(ActionEvent actionEvent)
    {
        GarageDoor gd = (GarageDoor)elements[0];
        if (gd.getStatus())
            gd.unlock();
        else
            gd.lock();
        updateButton(btnGarage, gd.getStatus());
    }

    public void switchWindow(ActionEvent actionEvent)
    {
        Window w = (Window)elements[1];
        if (w.getStatus())
            w.unlock();
        else
            w.lock();
        updateButton(btnWindow, w.getStatus());
    }

    public void switchHeating(ActionEvent actionEvent)
    {
        Heating h = (Heating)elements[2];
        if (h.getStatus())
            h.switchOff();
        else
            h.switchOn();
        updateButton(btnHeating, h.getStatus());
    }

    public void switchOven(ActionEvent actionEvent)
    {
        Oven o = (Oven)elements[3];
        if (o.getStatus())
            o.switchOff();
        else
            o.switchOn();
        updateButton(btnOven, o.getStatus());
    }

    public void switchBathroomLight(ActionEvent actionEvent)
    {
        Light l = (Light)elements[4];
        if (l.getStatus())
            l.switchOff();
        else
            l.switchOn();
        updateButton(btnBathroomLight, l.getStatus());
    }

    public void switchLivingLight(ActionEvent actionEvent)
    {
        Light l = (Light)elements[5];
        if (l.getStatus())
            l.switchOff();
        else
            l.switchOn();
        updateButton(btnLivingLight, l.getStatus());
    }

    public void applyChanges(ActionEvent actionEvent)
    {
        saveStatus();
    }

    private void updateButton(Button b, boolean status)
    {
        if (status)
        {
            b.setText("ON");
            b.setStyle("-fx-background-color: green");
        }
        else
        {
            b.setText("OFF");
            b.setStyle("-fx-background-color: red");
        }
    }

    private void updateUI()
    {
        updateButton(btnGarage, ((GarageDoor)elements[0]).getStatus());
        comboGarage.getSelectionModel().select("" + ((GarageDoor)elements[0]).getPercent());
        updateButton(btnWindow, ((Window)elements[1]).getStatus());
        comboWindow.getSelectionModel().select("" + ((Window)elements[1]).getBlind().getPercent());
        updateButton(btnHeating, ((Heating)elements[2]).getStatus());
        txtHeating.setText("" + ((Heating)elements[2]).getTemperature());
        updateButton(btnOven, ((Oven)elements[3]).getStatus());
        txtOven.setText("" + ((Oven)elements[3]).getTemperature());
        updateButton(btnBathroomLight, ((Light)elements[4]).getStatus());
        updateButton(btnLivingLight, ((Light)elements[5]).getStatus());
    }

    private void updateElements()
    {
        if (btnGarage.getText().equals("ON"))
            ((GarageDoor)elements[0]).lock();
        else
            ((GarageDoor)elements[0]).unlock();
        ((GarageDoor)elements[0]).lower();
        ((GarageDoor)elements[0]).raise(Integer.parseInt(comboGarage.getValue()));

        if (btnWindow.getText().equals("ON"))
            ((Window)elements[1]).lock();
        else
            ((Window)elements[1]).unlock();
        ((Window)elements[1]).getBlind().lower();
        ((Window)elements[1]).getBlind().raise(Integer.parseInt(comboWindow.getValue()));

        if (btnHeating.getText().equals("ON"))
            ((Heating)elements[2]).switchOn();
        else
            ((Heating)elements[2]).switchOff();
        ((Heating)elements[2]).setTemperature(Integer.parseInt(txtHeating.getText()));

        if (btnOven.getText().equals("ON"))
            ((Oven)elements[3]).switchOn();
        else
            ((Oven)elements[3]).switchOff();
        ((Oven)elements[3]).setTemperature(Integer.parseInt(txtOven.getText()));

        if (btnBathroomLight.getText().equals("ON"))
            ((Light)elements[4]).switchOn();
        else
            ((Light)elements[4]).switchOff();

        if (btnLivingLight.getText().equals("ON"))
            ((Light)elements[5]).switchOn();
        else
            ((Light)elements[5]).switchOff();
    }
}
