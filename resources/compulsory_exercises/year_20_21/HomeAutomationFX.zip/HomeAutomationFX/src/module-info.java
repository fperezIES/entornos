module HomeAutomationFX {

    requires javafx.fxml;
    requires javafx.controls;

    opens automation.fx;
}